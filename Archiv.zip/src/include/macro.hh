#ifdef _MACRO_HH_
#define _MACRO_HH_

#include <string>




#endif