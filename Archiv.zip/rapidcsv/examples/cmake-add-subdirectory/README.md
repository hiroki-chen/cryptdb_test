CMake Add Subdirectory Example Project
======================================

Build Steps
-----------
Commands to build the example project:

    ln -s ../.. rapidcsv
    mkdir -p build && cd build && cmake .. && make


