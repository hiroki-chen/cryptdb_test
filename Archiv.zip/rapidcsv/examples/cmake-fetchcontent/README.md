CMake FetchContent Example Project
==================================

Build Steps
-----------
Commands to build the example project:

    mkdir -p build && cd build && cmake .. && make


